package main

// @title Swagger Example API
// @version 1.0
// @description.markdown markdown.md
// @termsOfService http://swagger.io/terms/

// @tag.name users
// @tag.description.markdown

func main() {}
