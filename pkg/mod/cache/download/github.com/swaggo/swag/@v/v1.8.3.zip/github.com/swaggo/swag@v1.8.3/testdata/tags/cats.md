## Cats 

Cats are also very cool!