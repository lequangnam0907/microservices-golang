package common

type Data struct {
	Value string `json:"message"`
}
