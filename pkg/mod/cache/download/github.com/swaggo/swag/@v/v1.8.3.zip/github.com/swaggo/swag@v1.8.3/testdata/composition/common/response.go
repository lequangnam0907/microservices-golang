package common

type ResponseFormat struct {
	Message string `json:"message"`
}
