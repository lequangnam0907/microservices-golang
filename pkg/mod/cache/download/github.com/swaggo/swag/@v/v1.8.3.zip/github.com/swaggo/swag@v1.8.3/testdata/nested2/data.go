package nested2

type Body struct {
	Value string `json:"value"`
}
